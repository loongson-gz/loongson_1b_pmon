int commit_message_init(void)
{
tgt_printf("This is pmon commit message\n");
tgt_printf("HashNumber: fc2223c2a284e540c3ac296a3c4aee43c7bc662f\n");
tgt_printf(" CommitAuthor: root\n");
tgt_printf(" CommitDate: Mon Nov 7 14:59:55 2011\n");
tgt_printf(" UserName: root\n");
tgt_printf(" MakeTime: 2011年 11月 08日 星期二 11:09:40 CST\n");
tgt_printf(" UserIP: IP not fond\n");
return 0;
}
