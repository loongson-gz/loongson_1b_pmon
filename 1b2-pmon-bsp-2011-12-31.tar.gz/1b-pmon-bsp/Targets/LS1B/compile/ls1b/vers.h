#define VERS "PMON2000 2.1 (ls1b) #741: 2011年 12月 30日 星期五 20:52:51 CST\r\n"
