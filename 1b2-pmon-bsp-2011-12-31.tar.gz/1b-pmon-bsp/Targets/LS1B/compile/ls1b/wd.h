#define	NWD	0
