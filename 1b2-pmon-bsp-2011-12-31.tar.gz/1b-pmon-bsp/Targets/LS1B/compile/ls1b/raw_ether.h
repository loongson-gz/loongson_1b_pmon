#define	NRAW_ETHER	1
