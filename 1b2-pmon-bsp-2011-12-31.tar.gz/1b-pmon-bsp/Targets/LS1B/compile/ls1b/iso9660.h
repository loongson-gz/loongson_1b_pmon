#define	NISO9660	0
