#define	NSDCARD	1
