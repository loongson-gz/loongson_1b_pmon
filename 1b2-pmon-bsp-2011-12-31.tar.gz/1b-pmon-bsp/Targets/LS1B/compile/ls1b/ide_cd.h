#define	NIDE_CD	0
