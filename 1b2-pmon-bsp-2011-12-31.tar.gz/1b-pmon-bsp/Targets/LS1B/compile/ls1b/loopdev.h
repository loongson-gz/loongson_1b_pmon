#define	NLOOPDEV	1
