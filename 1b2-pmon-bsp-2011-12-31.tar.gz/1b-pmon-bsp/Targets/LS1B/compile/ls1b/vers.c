char ostype[] = "PMON2000";
char osrelease[] = "2.1";
char osversion[] = "ls1b#741";
char sccs[8] = { ' ', ' ', ' ', ' ', '@', '(', '#', ')' };
char vers[] =
    "GitHashNumber: de83dd0362190248e7ac0ae8f5dc58e11f81d906\nCommitAuthor: 95cda88\nCommitDate: root <root@localhost> Date: Thu Nov\nuserIP: \nUsrName: root\nMakeTime: 2011年 12月 30日 星期五 20:52:51 CST";
