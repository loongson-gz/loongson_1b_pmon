#ifndef _gcTESTFILTERBLIT_H_
#define _gcTESTFILTERBLIT_H_

void testFilterBlit(
	gcSURFACEINFO* Target
	);

void testFilterBlitFormats(
	gcSURFACEINFO* Target
	);

#endif // _gcTESTFILTERBLIT_H_
