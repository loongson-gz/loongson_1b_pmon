#ifndef _gcTESTMASK_H_
#define _gcTESTMASK_H_

void testMaskedBlitRandom(
	gcSURFACEINFO* Target
	);

#endif // _gcTESTMASK_H_
