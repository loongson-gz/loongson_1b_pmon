#ifndef _gcTESTROTATION_H_
#define _gcTESTROTATION_H_

void testRotation(
	gcSURFACEINFO* Target
	);


#endif // _gcTESTROTATION_H_
