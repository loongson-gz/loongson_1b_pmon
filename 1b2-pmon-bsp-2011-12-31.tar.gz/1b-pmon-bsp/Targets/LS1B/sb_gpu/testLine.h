#ifndef _gcTESTLINE_H_
#define _gcTESTLINE_H_

void testLine(
	gcSURFACEINFO* Target
	);

void testRandomLine(
	gcSURFACEINFO* Target
	);

#endif // _gcTESTLINE_H_
