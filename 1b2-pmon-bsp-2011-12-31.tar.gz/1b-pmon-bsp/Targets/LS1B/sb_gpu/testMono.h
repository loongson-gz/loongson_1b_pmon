#ifndef _gcTESTMONO_H_
#define _gcTESTMONO_H_

void testMonoExpand(
	gcSURFACEINFO* Target
	);

void testMonoExpandRandom(
	gcSURFACEINFO* Target
	);

#endif // _gcTESTMONO_H_
