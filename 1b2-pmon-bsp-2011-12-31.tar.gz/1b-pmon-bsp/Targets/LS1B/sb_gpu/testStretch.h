#ifndef _gcTESTSTRETCH_H_
#define _gcTESTSTRETCH_H_

void testStretch(
	gcSURFACEINFO* Target
	);

void testRandomStretch(
	gcSURFACEINFO* Target
	);

#endif // _gcTESTSTRETCH_H_
