#define	NSD	0
