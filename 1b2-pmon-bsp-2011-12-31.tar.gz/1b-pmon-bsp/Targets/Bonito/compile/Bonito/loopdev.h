#define	NLOOPDEV	0
