#define	NTCP	0
