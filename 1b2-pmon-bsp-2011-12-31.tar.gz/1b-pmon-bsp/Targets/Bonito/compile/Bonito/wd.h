#define	NWD	1
