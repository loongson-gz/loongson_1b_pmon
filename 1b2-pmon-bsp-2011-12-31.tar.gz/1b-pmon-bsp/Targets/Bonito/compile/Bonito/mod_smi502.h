#define	NMOD_SMI502	0
