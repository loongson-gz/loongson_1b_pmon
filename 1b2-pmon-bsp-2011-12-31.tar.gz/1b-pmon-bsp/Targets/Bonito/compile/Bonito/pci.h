#define	NPCI	1
#define	NCS5536	0
