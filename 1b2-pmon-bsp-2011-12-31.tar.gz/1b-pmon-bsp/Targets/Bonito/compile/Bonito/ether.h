#define	NETHER	1
