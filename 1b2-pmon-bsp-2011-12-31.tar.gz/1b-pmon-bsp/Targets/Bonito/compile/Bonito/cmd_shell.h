#define	NCMD_SHELL	1
#define	NCMD_VERS	1
#define	NCMD_HELP	1
#define	NCMD_EVAL	1
