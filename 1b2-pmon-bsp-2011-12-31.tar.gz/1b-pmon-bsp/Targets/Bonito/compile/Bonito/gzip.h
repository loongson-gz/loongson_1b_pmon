#define	NGZIP	0
