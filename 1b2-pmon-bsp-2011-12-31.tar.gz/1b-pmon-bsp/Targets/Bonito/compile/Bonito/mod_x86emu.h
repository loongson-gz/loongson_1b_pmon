#define	NMOD_X86EMU	0
