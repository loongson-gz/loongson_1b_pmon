
#ifndef __LX_PCI_MACHDEP_H__
#define __LX_PCI_MACHDEP_H__

#include <linux/pci.h>

#define PCIVERBOSE

#endif	/*	__LX_PCI_MACHDEP_H__ */
