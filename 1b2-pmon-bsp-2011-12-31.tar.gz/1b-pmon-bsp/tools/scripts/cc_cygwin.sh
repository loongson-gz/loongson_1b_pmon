export CC=/usr/local/powerpc-linux/bin/gcc
export AS=/usr/local/powerpc-linux/bin/as
export RANLIB=/usr/local/powerpc-linux/bin/ranlib
export LD=/usr/local/powerpc-linux/bin/ld
export AR=/usr/local/powerpc-linux/bin/ar
export STRIP=/usr/local/powerpc-linux/strip
#export SIZE=/usr/local/powerpc-linux/size
export MKDEP=makedepend
